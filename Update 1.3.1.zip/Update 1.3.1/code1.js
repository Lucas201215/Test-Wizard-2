gdjs.Question_32OneCode = {};
gdjs.Question_32OneCode.GDQuestionObjects1= [];
gdjs.Question_32OneCode.GDQuestionObjects2= [];
gdjs.Question_32OneCode.GDBackplate_9595oneObjects1= [];
gdjs.Question_32OneCode.GDBackplate_9595oneObjects2= [];
gdjs.Question_32OneCode.GDBackplate_9595twoObjects1= [];
gdjs.Question_32OneCode.GDBackplate_9595twoObjects2= [];
gdjs.Question_32OneCode.GDAnswer_9595oneObjects1= [];
gdjs.Question_32OneCode.GDAnswer_9595oneObjects2= [];
gdjs.Question_32OneCode.GDAnswer_9595TwoObjects1= [];
gdjs.Question_32OneCode.GDAnswer_9595TwoObjects2= [];
gdjs.Question_32OneCode.GDBackplate_9595threeObjects1= [];
gdjs.Question_32OneCode.GDBackplate_9595threeObjects2= [];
gdjs.Question_32OneCode.GDNextObjects1= [];
gdjs.Question_32OneCode.GDNextObjects2= [];
gdjs.Question_32OneCode.GDCorrectObjects1= [];
gdjs.Question_32OneCode.GDCorrectObjects2= [];
gdjs.Question_32OneCode.GDIncorrectObjects1= [];
gdjs.Question_32OneCode.GDIncorrectObjects2= [];
gdjs.Question_32OneCode.GDdebug_9595modeObjects1= [];
gdjs.Question_32OneCode.GDdebug_9595modeObjects2= [];
gdjs.Question_32OneCode.GDdebug_9595mode2Objects1= [];
gdjs.Question_32OneCode.GDdebug_9595mode2Objects2= [];
gdjs.Question_32OneCode.GDPlayerObjects1= [];
gdjs.Question_32OneCode.GDPlayerObjects2= [];


gdjs.Question_32OneCode.mapOfGDgdjs_9546Question_959532OneCode_9546GDBackplate_95959595oneObjects1Objects = Hashtable.newFrom({"Backplate_one": gdjs.Question_32OneCode.GDBackplate_9595oneObjects1});
gdjs.Question_32OneCode.mapOfGDgdjs_9546Question_959532OneCode_9546GDBackplate_95959595twoObjects1Objects = Hashtable.newFrom({"Backplate_two": gdjs.Question_32OneCode.GDBackplate_9595twoObjects1});
gdjs.Question_32OneCode.mapOfGDgdjs_9546Question_959532OneCode_9546GDBackplate_95959595threeObjects1Objects = Hashtable.newFrom({"Backplate_three": gdjs.Question_32OneCode.GDBackplate_9595threeObjects1});
gdjs.Question_32OneCode.mapOfGDgdjs_9546Question_959532OneCode_9546GDdebug_95959595modeObjects1Objects = Hashtable.newFrom({"debug_mode": gdjs.Question_32OneCode.GDdebug_9595modeObjects1});
gdjs.Question_32OneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Backplate_three"), gdjs.Question_32OneCode.GDBackplate_9595threeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Correct"), gdjs.Question_32OneCode.GDCorrectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Incorrect"), gdjs.Question_32OneCode.GDIncorrectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.Question_32OneCode.GDNextObjects1);
{for(var i = 0, len = gdjs.Question_32OneCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDNextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDBackplate_9595threeObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDBackplate_9595threeObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDCorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDCorrectObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDIncorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDIncorrectObjects1[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("debug_mode"), gdjs.Question_32OneCode.GDdebug_9595modeObjects1);
gdjs.copyArray(runtimeScene.getObjects("debug_mode2"), gdjs.Question_32OneCode.GDdebug_9595mode2Objects1);
{for(var i = 0, len = gdjs.Question_32OneCode.GDdebug_9595modeObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDdebug_9595modeObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDdebug_9595mode2Objects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDdebug_9595mode2Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backplate_one"), gdjs.Question_32OneCode.GDBackplate_9595oneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Question_32OneCode.mapOfGDgdjs_9546Question_959532OneCode_9546GDBackplate_95959595oneObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer_Two"), gdjs.Question_32OneCode.GDAnswer_9595TwoObjects1);
gdjs.copyArray(runtimeScene.getObjects("Answer_one"), gdjs.Question_32OneCode.GDAnswer_9595oneObjects1);
gdjs.copyArray(runtimeScene.getObjects("Backplate_three"), gdjs.Question_32OneCode.GDBackplate_9595threeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Correct"), gdjs.Question_32OneCode.GDCorrectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Incorrect"), gdjs.Question_32OneCode.GDIncorrectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.Question_32OneCode.GDNextObjects1);
{for(var i = 0, len = gdjs.Question_32OneCode.GDAnswer_9595oneObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDAnswer_9595oneObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDAnswer_9595TwoObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDAnswer_9595TwoObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDBackplate_9595threeObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDBackplate_9595threeObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDNextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDCorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDCorrectObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDIncorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDIncorrectObjects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backplate_two"), gdjs.Question_32OneCode.GDBackplate_9595twoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Question_32OneCode.mapOfGDgdjs_9546Question_959532OneCode_9546GDBackplate_95959595twoObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer_Two"), gdjs.Question_32OneCode.GDAnswer_9595TwoObjects1);
gdjs.copyArray(runtimeScene.getObjects("Answer_one"), gdjs.Question_32OneCode.GDAnswer_9595oneObjects1);
gdjs.copyArray(runtimeScene.getObjects("Backplate_three"), gdjs.Question_32OneCode.GDBackplate_9595threeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Correct"), gdjs.Question_32OneCode.GDCorrectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Incorrect"), gdjs.Question_32OneCode.GDIncorrectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.Question_32OneCode.GDNextObjects1);
{for(var i = 0, len = gdjs.Question_32OneCode.GDAnswer_9595oneObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDAnswer_9595oneObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDAnswer_9595TwoObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDAnswer_9595TwoObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDBackplate_9595threeObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDBackplate_9595threeObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDNextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDCorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDCorrectObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32OneCode.GDIncorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32OneCode.GDIncorrectObjects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backplate_three"), gdjs.Question_32OneCode.GDBackplate_9595threeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Question_32OneCode.mapOfGDgdjs_9546Question_959532OneCode_9546GDBackplate_95959595threeObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Beginning of Weirdness", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("debug_mode"), gdjs.Question_32OneCode.GDdebug_9595modeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Question_32OneCode.mapOfGDgdjs_9546Question_959532OneCode_9546GDdebug_95959595modeObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "What the Heck?!", false);
}}

}


};

gdjs.Question_32OneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Question_32OneCode.GDQuestionObjects1.length = 0;
gdjs.Question_32OneCode.GDQuestionObjects2.length = 0;
gdjs.Question_32OneCode.GDBackplate_9595oneObjects1.length = 0;
gdjs.Question_32OneCode.GDBackplate_9595oneObjects2.length = 0;
gdjs.Question_32OneCode.GDBackplate_9595twoObjects1.length = 0;
gdjs.Question_32OneCode.GDBackplate_9595twoObjects2.length = 0;
gdjs.Question_32OneCode.GDAnswer_9595oneObjects1.length = 0;
gdjs.Question_32OneCode.GDAnswer_9595oneObjects2.length = 0;
gdjs.Question_32OneCode.GDAnswer_9595TwoObjects1.length = 0;
gdjs.Question_32OneCode.GDAnswer_9595TwoObjects2.length = 0;
gdjs.Question_32OneCode.GDBackplate_9595threeObjects1.length = 0;
gdjs.Question_32OneCode.GDBackplate_9595threeObjects2.length = 0;
gdjs.Question_32OneCode.GDNextObjects1.length = 0;
gdjs.Question_32OneCode.GDNextObjects2.length = 0;
gdjs.Question_32OneCode.GDCorrectObjects1.length = 0;
gdjs.Question_32OneCode.GDCorrectObjects2.length = 0;
gdjs.Question_32OneCode.GDIncorrectObjects1.length = 0;
gdjs.Question_32OneCode.GDIncorrectObjects2.length = 0;
gdjs.Question_32OneCode.GDdebug_9595modeObjects1.length = 0;
gdjs.Question_32OneCode.GDdebug_9595modeObjects2.length = 0;
gdjs.Question_32OneCode.GDdebug_9595mode2Objects1.length = 0;
gdjs.Question_32OneCode.GDdebug_9595mode2Objects2.length = 0;
gdjs.Question_32OneCode.GDPlayerObjects1.length = 0;
gdjs.Question_32OneCode.GDPlayerObjects2.length = 0;

gdjs.Question_32OneCode.eventsList0(runtimeScene);

return;

}

gdjs['Question_32OneCode'] = gdjs.Question_32OneCode;
