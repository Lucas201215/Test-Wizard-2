gdjs.Death_32ZoneCode = {};
gdjs.Death_32ZoneCode.GDNewTextObjects1= [];
gdjs.Death_32ZoneCode.GDNewTextObjects2= [];
gdjs.Death_32ZoneCode.GDNewText2Objects1= [];
gdjs.Death_32ZoneCode.GDNewText2Objects2= [];
gdjs.Death_32ZoneCode.GDNewText3Objects1= [];
gdjs.Death_32ZoneCode.GDNewText3Objects2= [];
gdjs.Death_32ZoneCode.GDPlayerObjects1= [];
gdjs.Death_32ZoneCode.GDPlayerObjects2= [];


gdjs.Death_32ZoneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Where am I?", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Thanks For Playing", false);
}}

}


};

gdjs.Death_32ZoneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Death_32ZoneCode.GDNewTextObjects1.length = 0;
gdjs.Death_32ZoneCode.GDNewTextObjects2.length = 0;
gdjs.Death_32ZoneCode.GDNewText2Objects1.length = 0;
gdjs.Death_32ZoneCode.GDNewText2Objects2.length = 0;
gdjs.Death_32ZoneCode.GDNewText3Objects1.length = 0;
gdjs.Death_32ZoneCode.GDNewText3Objects2.length = 0;
gdjs.Death_32ZoneCode.GDPlayerObjects1.length = 0;
gdjs.Death_32ZoneCode.GDPlayerObjects2.length = 0;

gdjs.Death_32ZoneCode.eventsList0(runtimeScene);

return;

}

gdjs['Death_32ZoneCode'] = gdjs.Death_32ZoneCode;
