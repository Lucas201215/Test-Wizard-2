gdjs.UnknownCode = {};


gdjs.UnknownCode.eventsList0 = function(runtimeScene) {

};

gdjs.UnknownCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.UnknownCode.eventsList0(runtimeScene);

return;

}

gdjs['UnknownCode'] = gdjs.UnknownCode;
