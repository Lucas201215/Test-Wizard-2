gdjs.Beginning_32of_32WeirdnessCode = {};
gdjs.Beginning_32of_32WeirdnessCode.GDFloorObjects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDFloorObjects2= [];
gdjs.Beginning_32of_32WeirdnessCode.GDTalkObjects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDTalkObjects2= [];
gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects2= [];
gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects2= [];
gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects2= [];
gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects2= [];
gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects2= [];
gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects2= [];
gdjs.Beginning_32of_32WeirdnessCode.GDDeveloper_9595FeaturesObjects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDDeveloper_9595FeaturesObjects2= [];
gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1= [];
gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects2= [];


gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1});
gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDTalkObjects1Objects = Hashtable.newFrom({"Talk": gdjs.Beginning_32of_32WeirdnessCode.GDTalkObjects1});
gdjs.Beginning_32of_32WeirdnessCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Question Two", false);
}}

}


};gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDRightObjects1Objects = Hashtable.newFrom({"Right": gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1});
gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDLeftObjects1Objects = Hashtable.newFrom({"Left": gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1});
gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDUpObjects1Objects = Hashtable.newFrom({"Up": gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1});
gdjs.Beginning_32of_32WeirdnessCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Developer_Features"), gdjs.Beginning_32of_32WeirdnessCode.GDDeveloper_9595FeaturesObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText2"), gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDDeveloper_9595FeaturesObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDDeveloper_9595FeaturesObjects1[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Down"), gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("Up"), gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Down"), gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("Up"), gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Talk"), gdjs.Beginning_32of_32WeirdnessCode.GDTalkObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDTalkObjects1Objects, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Down"), gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Beginning_32of_32WeirdnessCode.GDFloorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText2"), gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects1);
/* Reuse gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1);
/* Reuse gdjs.Beginning_32of_32WeirdnessCode.GDTalkObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Up"), gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDFloorObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDFloorObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDTalkObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDTalkObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "0;0;0");
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1[i].hide();
}
}
{ //Subevents
gdjs.Beginning_32of_32WeirdnessCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Player left");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Player left");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Player Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Player Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Player Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Player Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDRightObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].setX(gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].getX() - (5));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDLeftObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].setX(gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].getX() + (5));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Up"), gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Beginning_32of_32WeirdnessCode.mapOfGDgdjs_9546Beginning_959532of_959532WeirdnessCode_9546GDUpObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].setY(gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1[i].getY() - (10));
}
}}

}


};

gdjs.Beginning_32of_32WeirdnessCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Beginning_32of_32WeirdnessCode.GDFloorObjects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDFloorObjects2.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDTalkObjects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDTalkObjects2.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDNewTextObjects2.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDNewText2Objects2.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDRightObjects2.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDLeftObjects2.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDUpObjects2.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDDownObjects2.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDDeveloper_9595FeaturesObjects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDDeveloper_9595FeaturesObjects2.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects1.length = 0;
gdjs.Beginning_32of_32WeirdnessCode.GDPlayerObjects2.length = 0;

gdjs.Beginning_32of_32WeirdnessCode.eventsList1(runtimeScene);

return;

}

gdjs['Beginning_32of_32WeirdnessCode'] = gdjs.Beginning_32of_32WeirdnessCode;
