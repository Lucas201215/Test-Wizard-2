gdjs.Question_32TwoCode = {};
gdjs.Question_32TwoCode.GDQuestionObjects1= [];
gdjs.Question_32TwoCode.GDQuestionObjects2= [];
gdjs.Question_32TwoCode.GDBackplate_9595oneObjects1= [];
gdjs.Question_32TwoCode.GDBackplate_9595oneObjects2= [];
gdjs.Question_32TwoCode.GDBacklate_9595TwoObjects1= [];
gdjs.Question_32TwoCode.GDBacklate_9595TwoObjects2= [];
gdjs.Question_32TwoCode.GDNewTextObjects1= [];
gdjs.Question_32TwoCode.GDNewTextObjects2= [];
gdjs.Question_32TwoCode.GDNewText2Objects1= [];
gdjs.Question_32TwoCode.GDNewText2Objects2= [];
gdjs.Question_32TwoCode.GDcorrectObjects1= [];
gdjs.Question_32TwoCode.GDcorrectObjects2= [];
gdjs.Question_32TwoCode.GDincorrectObjects1= [];
gdjs.Question_32TwoCode.GDincorrectObjects2= [];
gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1= [];
gdjs.Question_32TwoCode.GDBackplate_9595threeObjects2= [];
gdjs.Question_32TwoCode.GDNextObjects1= [];
gdjs.Question_32TwoCode.GDNextObjects2= [];
gdjs.Question_32TwoCode.GDPlayerObjects1= [];
gdjs.Question_32TwoCode.GDPlayerObjects2= [];


gdjs.Question_32TwoCode.mapOfGDgdjs_9546Question_959532TwoCode_9546GDBackplate_95959595oneObjects1Objects = Hashtable.newFrom({"Backplate_one": gdjs.Question_32TwoCode.GDBackplate_9595oneObjects1});
gdjs.Question_32TwoCode.mapOfGDgdjs_9546Question_959532TwoCode_9546GDBacklate_95959595TwoObjects1Objects = Hashtable.newFrom({"Backlate_Two": gdjs.Question_32TwoCode.GDBacklate_9595TwoObjects1});
gdjs.Question_32TwoCode.mapOfGDgdjs_9546Question_959532TwoCode_9546GDBackplate_95959595threeObjects1Objects = Hashtable.newFrom({"Backplate_three": gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1});
gdjs.Question_32TwoCode.mapOfGDgdjs_9546Question_959532TwoCode_9546GDBackplate_95959595threeObjects1Objects = Hashtable.newFrom({"Backplate_three": gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1});
gdjs.Question_32TwoCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Backplate_three"), gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.Question_32TwoCode.GDNextObjects1);
gdjs.copyArray(runtimeScene.getObjects("correct"), gdjs.Question_32TwoCode.GDcorrectObjects1);
gdjs.copyArray(runtimeScene.getObjects("incorrect"), gdjs.Question_32TwoCode.GDincorrectObjects1);
{gdjs.evtTools.input.showCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDcorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDcorrectObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDincorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDincorrectObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDNextObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backplate_one"), gdjs.Question_32TwoCode.GDBackplate_9595oneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Question_32TwoCode.mapOfGDgdjs_9546Question_959532TwoCode_9546GDBackplate_95959595oneObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Backplate_three"), gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Question_32TwoCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText2"), gdjs.Question_32TwoCode.GDNewText2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.Question_32TwoCode.GDNextObjects1);
gdjs.copyArray(runtimeScene.getObjects("correct"), gdjs.Question_32TwoCode.GDcorrectObjects1);
gdjs.copyArray(runtimeScene.getObjects("incorrect"), gdjs.Question_32TwoCode.GDincorrectObjects1);
{for(var i = 0, len = gdjs.Question_32TwoCode.GDcorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDcorrectObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDincorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDincorrectObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDNewTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDNewText2Objects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDNewText2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDNextObjects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backlate_Two"), gdjs.Question_32TwoCode.GDBacklate_9595TwoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Question_32TwoCode.mapOfGDgdjs_9546Question_959532TwoCode_9546GDBacklate_95959595TwoObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Backplate_three"), gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Question_32TwoCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText2"), gdjs.Question_32TwoCode.GDNewText2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.Question_32TwoCode.GDNextObjects1);
gdjs.copyArray(runtimeScene.getObjects("correct"), gdjs.Question_32TwoCode.GDcorrectObjects1);
gdjs.copyArray(runtimeScene.getObjects("incorrect"), gdjs.Question_32TwoCode.GDincorrectObjects1);
{for(var i = 0, len = gdjs.Question_32TwoCode.GDcorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDcorrectObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDincorrectObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDincorrectObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDNewTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDNewText2Objects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDNewText2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Question_32TwoCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.Question_32TwoCode.GDNextObjects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backplate_three"), gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Question_32TwoCode.mapOfGDgdjs_9546Question_959532TwoCode_9546GDBackplate_95959595threeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "What the Heck?!", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backplate_three"), gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Question_32TwoCode.mapOfGDgdjs_9546Question_959532TwoCode_9546GDBackplate_95959595threeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Thanks For Playing", false);
}}

}


};

gdjs.Question_32TwoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Question_32TwoCode.GDQuestionObjects1.length = 0;
gdjs.Question_32TwoCode.GDQuestionObjects2.length = 0;
gdjs.Question_32TwoCode.GDBackplate_9595oneObjects1.length = 0;
gdjs.Question_32TwoCode.GDBackplate_9595oneObjects2.length = 0;
gdjs.Question_32TwoCode.GDBacklate_9595TwoObjects1.length = 0;
gdjs.Question_32TwoCode.GDBacklate_9595TwoObjects2.length = 0;
gdjs.Question_32TwoCode.GDNewTextObjects1.length = 0;
gdjs.Question_32TwoCode.GDNewTextObjects2.length = 0;
gdjs.Question_32TwoCode.GDNewText2Objects1.length = 0;
gdjs.Question_32TwoCode.GDNewText2Objects2.length = 0;
gdjs.Question_32TwoCode.GDcorrectObjects1.length = 0;
gdjs.Question_32TwoCode.GDcorrectObjects2.length = 0;
gdjs.Question_32TwoCode.GDincorrectObjects1.length = 0;
gdjs.Question_32TwoCode.GDincorrectObjects2.length = 0;
gdjs.Question_32TwoCode.GDBackplate_9595threeObjects1.length = 0;
gdjs.Question_32TwoCode.GDBackplate_9595threeObjects2.length = 0;
gdjs.Question_32TwoCode.GDNextObjects1.length = 0;
gdjs.Question_32TwoCode.GDNextObjects2.length = 0;
gdjs.Question_32TwoCode.GDPlayerObjects1.length = 0;
gdjs.Question_32TwoCode.GDPlayerObjects2.length = 0;

gdjs.Question_32TwoCode.eventsList0(runtimeScene);

return;

}

gdjs['Question_32TwoCode'] = gdjs.Question_32TwoCode;
