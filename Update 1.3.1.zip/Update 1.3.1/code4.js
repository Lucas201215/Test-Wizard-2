gdjs.What_32the_32Heck_63_33Code = {};
gdjs.What_32the_32Heck_63_33Code.GDplatformObjects1= [];
gdjs.What_32the_32Heck_63_33Code.GDplatformObjects2= [];
gdjs.What_32the_32Heck_63_33Code.GDplatformObjects3= [];
gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1= [];
gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects2= [];
gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects3= [];
gdjs.What_32the_32Heck_63_33Code.GDBouncyBlockObjects1= [];
gdjs.What_32the_32Heck_63_33Code.GDBouncyBlockObjects2= [];
gdjs.What_32the_32Heck_63_33Code.GDBouncyBlockObjects3= [];
gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1= [];
gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2= [];
gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects3= [];


gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1});
gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDLoreblockObjects1Objects = Hashtable.newFrom({"Loreblock": gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1});
gdjs.What_32the_32Heck_63_33Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Player left");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Player left");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Player Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Player Idle");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Player Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Player Idle");
}
}}

}


};gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1});
gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDLoreblockObjects1Objects = Hashtable.newFrom({"Loreblock": gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1});
gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1});
gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDBouncyBlockObjects1Objects = Hashtable.newFrom({"BouncyBlock": gdjs.What_32the_32Heck_63_33Code.GDBouncyBlockObjects1});
gdjs.What_32the_32Heck_63_33Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Loreblock"), gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDLoreblockObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1 */
/* Reuse gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("platform"), gdjs.What_32the_32Heck_63_33Code.GDplatformObjects1);
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "0;0;0");
}{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDplatformObjects1.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDplatformObjects1[i].hide();
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Death Zone", false);
}}

}


{


gdjs.What_32the_32Heck_63_33Code.eventsList0(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Loreblock"), gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDLoreblockObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1 */
/* Reuse gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("platform"), gdjs.What_32the_32Heck_63_33Code.GDplatformObjects1);
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "0;0;0");
}{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDplatformObjects1.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDplatformObjects1[i].hide();
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Death Zone", false);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1.length !== 0 ? gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BouncyBlock"), gdjs.What_32the_32Heck_63_33Code.GDBouncyBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.What_32the_32Heck_63_33Code.mapOfGDgdjs_9546What_959532the_959532Heck_959563_959533Code_9546GDBouncyBlockObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setGravity(gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").getGravity() / (2));
}
}}

}


};

gdjs.What_32the_32Heck_63_33Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.What_32the_32Heck_63_33Code.GDplatformObjects1.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDplatformObjects2.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDplatformObjects3.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects1.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects2.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDLoreblockObjects3.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDBouncyBlockObjects1.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDBouncyBlockObjects2.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDBouncyBlockObjects3.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects1.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects2.length = 0;
gdjs.What_32the_32Heck_63_33Code.GDPlayerObjects3.length = 0;

gdjs.What_32the_32Heck_63_33Code.eventsList1(runtimeScene);

return;

}

gdjs['What_32the_32Heck_63_33Code'] = gdjs.What_32the_32Heck_63_33Code;
