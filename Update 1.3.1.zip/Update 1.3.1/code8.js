gdjs.Thanks_32For_32PlayingCode = {};


gdjs.Thanks_32For_32PlayingCode.eventsList0 = function(runtimeScene) {

};

gdjs.Thanks_32For_32PlayingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.Thanks_32For_32PlayingCode.eventsList0(runtimeScene);

return;

}

gdjs['Thanks_32For_32PlayingCode'] = gdjs.Thanks_32For_32PlayingCode;
