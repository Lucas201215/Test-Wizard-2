gdjs.Where_32am_32I_63Code = {};
gdjs.Where_32am_32I_63Code.GDTextObjects1= [];
gdjs.Where_32am_32I_63Code.GDTextObjects2= [];
gdjs.Where_32am_32I_63Code.GDNewTextObjects1= [];
gdjs.Where_32am_32I_63Code.GDNewTextObjects2= [];
gdjs.Where_32am_32I_63Code.GDPlayerObjects1= [];
gdjs.Where_32am_32I_63Code.GDPlayerObjects2= [];


gdjs.Where_32am_32I_63Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Where_32am_32I_63Code.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Text"), gdjs.Where_32am_32I_63Code.GDTextObjects1);
{for(var i = 0, len = gdjs.Where_32am_32I_63Code.GDTextObjects1.length ;i < len;++i) {
    gdjs.Where_32am_32I_63Code.GDTextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Where_32am_32I_63Code.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Where_32am_32I_63Code.GDNewTextObjects1[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Text"), gdjs.Where_32am_32I_63Code.GDTextObjects1);
{for(var i = 0, len = gdjs.Where_32am_32I_63Code.GDTextObjects1.length ;i < len;++i) {
    gdjs.Where_32am_32I_63Code.GDTextObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Where_32am_32I_63Code.GDNewTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Where_32am_32I_63Code.GDNewTextObjects1.length;i<l;++i) {
    if ( gdjs.Where_32am_32I_63Code.GDNewTextObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Where_32am_32I_63Code.GDNewTextObjects1[k] = gdjs.Where_32am_32I_63Code.GDNewTextObjects1[i];
        ++k;
    }
}
gdjs.Where_32am_32I_63Code.GDNewTextObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Where_32am_32I_63Code.GDNewTextObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Text"), gdjs.Where_32am_32I_63Code.GDTextObjects1);
{for(var i = 0, len = gdjs.Where_32am_32I_63Code.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Where_32am_32I_63Code.GDNewTextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Where_32am_32I_63Code.GDTextObjects1.length ;i < len;++i) {
    gdjs.Where_32am_32I_63Code.GDTextObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Where_32am_32I_63Code.GDNewTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Where_32am_32I_63Code.GDNewTextObjects1.length;i<l;++i) {
    if ( gdjs.Where_32am_32I_63Code.GDNewTextObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Where_32am_32I_63Code.GDNewTextObjects1[k] = gdjs.Where_32am_32I_63Code.GDNewTextObjects1[i];
        ++k;
    }
}
gdjs.Where_32am_32I_63Code.GDNewTextObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Unknown", false);
}}

}


};

gdjs.Where_32am_32I_63Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Where_32am_32I_63Code.GDTextObjects1.length = 0;
gdjs.Where_32am_32I_63Code.GDTextObjects2.length = 0;
gdjs.Where_32am_32I_63Code.GDNewTextObjects1.length = 0;
gdjs.Where_32am_32I_63Code.GDNewTextObjects2.length = 0;
gdjs.Where_32am_32I_63Code.GDPlayerObjects1.length = 0;
gdjs.Where_32am_32I_63Code.GDPlayerObjects2.length = 0;

gdjs.Where_32am_32I_63Code.eventsList0(runtimeScene);

return;

}

gdjs['Where_32am_32I_63Code'] = gdjs.Where_32am_32I_63Code;
