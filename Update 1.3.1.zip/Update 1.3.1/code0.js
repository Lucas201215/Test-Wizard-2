gdjs.Title_32ScreenCode = {};
gdjs.Title_32ScreenCode.GDTitleObjects1= [];
gdjs.Title_32ScreenCode.GDTitleObjects2= [];
gdjs.Title_32ScreenCode.GDOption_9595oneObjects1= [];
gdjs.Title_32ScreenCode.GDOption_9595oneObjects2= [];
gdjs.Title_32ScreenCode.GDOption_95952Objects1= [];
gdjs.Title_32ScreenCode.GDOption_95952Objects2= [];
gdjs.Title_32ScreenCode.GDStartObjects1= [];
gdjs.Title_32ScreenCode.GDStartObjects2= [];
gdjs.Title_32ScreenCode.GDBackplate_9595twoObjects1= [];
gdjs.Title_32ScreenCode.GDBackplate_9595twoObjects2= [];
gdjs.Title_32ScreenCode.GDPlayerObjects1= [];
gdjs.Title_32ScreenCode.GDPlayerObjects2= [];


gdjs.Title_32ScreenCode.mapOfGDgdjs_9546Title_959532ScreenCode_9546GDOption_95959595oneObjects1Objects = Hashtable.newFrom({"Option_one": gdjs.Title_32ScreenCode.GDOption_9595oneObjects1});
gdjs.Title_32ScreenCode.mapOfGDgdjs_9546Title_959532ScreenCode_9546GDBackplate_95959595twoObjects1Objects = Hashtable.newFrom({"Backplate_two": gdjs.Title_32ScreenCode.GDBackplate_9595twoObjects1});
gdjs.Title_32ScreenCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Option_one"), gdjs.Title_32ScreenCode.GDOption_9595oneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_9546Title_959532ScreenCode_9546GDOption_95959595oneObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Question One", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.window.setAdaptGameResolutionAtRuntime(runtimeScene, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backplate_two"), gdjs.Title_32ScreenCode.GDBackplate_9595twoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32ScreenCode.mapOfGDgdjs_9546Title_959532ScreenCode_9546GDBackplate_95959595twoObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "What the Heck?!", false);
}}

}


};

gdjs.Title_32ScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Title_32ScreenCode.GDTitleObjects1.length = 0;
gdjs.Title_32ScreenCode.GDTitleObjects2.length = 0;
gdjs.Title_32ScreenCode.GDOption_9595oneObjects1.length = 0;
gdjs.Title_32ScreenCode.GDOption_9595oneObjects2.length = 0;
gdjs.Title_32ScreenCode.GDOption_95952Objects1.length = 0;
gdjs.Title_32ScreenCode.GDOption_95952Objects2.length = 0;
gdjs.Title_32ScreenCode.GDStartObjects1.length = 0;
gdjs.Title_32ScreenCode.GDStartObjects2.length = 0;
gdjs.Title_32ScreenCode.GDBackplate_9595twoObjects1.length = 0;
gdjs.Title_32ScreenCode.GDBackplate_9595twoObjects2.length = 0;
gdjs.Title_32ScreenCode.GDPlayerObjects1.length = 0;
gdjs.Title_32ScreenCode.GDPlayerObjects2.length = 0;

gdjs.Title_32ScreenCode.eventsList0(runtimeScene);

return;

}

gdjs['Title_32ScreenCode'] = gdjs.Title_32ScreenCode;
